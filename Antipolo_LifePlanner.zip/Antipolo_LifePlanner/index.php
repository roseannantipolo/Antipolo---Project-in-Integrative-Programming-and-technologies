<?php require 'db_connection.php' ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>ANTIPOLO - Life Planner</title>
  <link rel="stylesheet" href="style.css">
  <script src="jquery-3.2.1.min.js"></script>
</head>

<body>
  <header class="intro">
    <div class="introduction">
      <h1>LIFE PLANNER</h1>
      <h3>Get Organized!</h3>
    </div>
    <div class="storage">
      <h2>To-Do-List</h2>
      <form action="addTask.php" method="POST">
        <input type="text" class="addTodo" name="addTodo" placeholder="Add your Tasks" />
        <button class="todobutton" name="taskBtn">
          <img src="add btn.png" />
        </button>
      </form>
      <?php $todos = $conn->query("SELECT * FROM todolist"); ?>

      <div class="listItems">
        <?php while ($todo = $todos->fetch(PDO::FETCH_ASSOC)) { ?>
          <center>
            <div class='elementItem'>
              <?php echo $todo['Task'] ?>
              <img class='checkIcon' src='check icon.png' onclick='completeTask(<?php echo "\"" . $todo["TodolistID"] . "\",\"" . $todo["Task"] . "\",\"todolist\"" ?>)'>
              <img class='deleteIcon' src='delete icon.png' onclick='deleteTask(<?php echo "\"" . $todo["TodolistID"] . "\", \"todolist\"" ?>)'>
            </div>
          </center>
        <?php } ?>
      </div>
    </div>

    <div class="container">
      <h2>Goals and Plans</h2>
      <form action="addTask.php" method="POST">
        <input type="text" name="addGoalsPlans" class="addGoalsPlans" placeholder="Add your Goals and Plans" />
        <button class="goalsPlansButton" name="goalsBtn">
          <img src="add btn.png" />
        </button>
      </form>
      <?php $todos = $conn->query("SELECT * FROM goalsplans"); ?>

      <div class="listItems">
        <?php while ($todo = $todos->fetch(PDO::FETCH_ASSOC)) { ?>
          <center>
            <div class='elementItem'>
              <?php echo $todo['ListOfGoalsPlans'] ?>
              <img class='checkIcon' src='check icon.png' onclick='completeTask(<?php echo "\"" . $todo["GoalsPlanID"] . "\",\"" . $todo["ListOfGoalsPlans"] . "\",\"goalsplans\"" ?>)'>
              <img class='deleteIcon' src='delete icon.png' onclick='deleteTask(<?php echo "\"" . $todo["GoalsPlanID"] . "\", \"goalsplans\"" ?>)' />
            </div>
          </center>
        <?php } ?>
      </div>
    </div>

    <div class="holder">
      <h2>Appointments</h2>
      <form action="addTask.php" method="POST">
        <input type="text" name="addAppointments" class="addAppointments" placeholder="Add your Appointments" />
        <button class="appointmentsButton" name="appointmentsBtn">
          <img src="add btn.png" />
        </button>
      </form>
      <?php $todos = $conn->query("SELECT * FROM appointments"); ?>

      <div class="listItems">
        <?php while ($todo = $todos->fetch(PDO::FETCH_ASSOC)) { ?>
          <center>
            <div class='elementItem'>
              <?php echo $todo['ListOfAppointments'] ?>
              <img class='checkIcon' src='check icon.png' onclick='completeTask(<?php echo "\"" . $todo["AppointmentID"] . "\",\"" . $todo["ListOfAppointments"] . "\",\"appointments\"" ?>)'>
              <img class='deleteIcon' src='delete icon.png' onclick='deleteTask(<?php echo "\"" . $todo["AppointmentID"] . "\", \"appointments\"" ?>)'>
            </div>
          </center>
        <?php } ?>
      </div>
    </div>

    <div class="repo">
      <h2>Errands</h2>
      <form action="addTask.php" method="POST">
        <input type="text" name="addErrands" class="addErrands" placeholder="Add your Errands" />
        <button class="errandsButton" name="errandsBtn">
          <img src="add btn.png" />
        </button>
      </form>
      <?php $todos = $conn->query("SELECT * FROM errands"); ?>

      <div class="listItems">
        <?php while ($todo = $todos->fetch(PDO::FETCH_ASSOC)) { ?>
          <center>
            <div class='elementItem'>
              <?php echo $todo['ListOfErrands'] ?>
              <img class='checkIcon' src='check icon.png' onclick='completeTask(<?php echo "\"" . $todo["ErrandsID"] . "\",\"" . $todo["ListOfErrands"] . "\",\"errands\"" ?>)'>
              <img class='deleteIcon' src='delete icon.png' onclick='deleteTask(<?php echo "\"" . $todo["ErrandsID"] . "\", \"errands\"" ?>)'>
            </div>
          </center> 
        <?php } ?>
      </div>
    </div>

  </header>
  <script src="todolist.js"></script>
</body>

</html>