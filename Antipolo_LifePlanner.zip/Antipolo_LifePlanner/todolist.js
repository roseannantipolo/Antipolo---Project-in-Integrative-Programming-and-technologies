function deleteTask(id, table) {
    $.post(
        "deleteTask.php",
        {
            id: id,
            table: table,
        },
        (data) => {}
    );
    location.reload();
}

function completeTask(id, description, table) {
    $.post(
        "completedTask.php",
        {
            id: id,
            description: description,
            table: table,
        },
        (data) => {}
    );
    location.reload();
}