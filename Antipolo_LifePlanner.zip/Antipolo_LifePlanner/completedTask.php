<?php
require 'db_connection.php';
$id = $_POST['id'];
$description = $_POST['description'];
$table = $_POST['table'];
$query;

switch ($table) {
    case "todolist":
        $query = "SELECT Status FROM todolist WHERE TodolistID = $id";
        $result = $conn->query($query);
        if ($result) {
            if ($result->rowCount() > 0) {
                while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                    $c = $row["Status"];
                    if ($c == "Not Completed") {
                        $description = "<strike>" . $description . "</strike>";
                        $query = "UPDATE todolist SET Task = '$description', Status = 'Completed' WHERE TodolistID = $id";
                    } else {
                        $description = str_replace("<strike>", "", $description);
                        $description = str_replace("</strike>", "", $description);
                        $query = "UPDATE todolist SET Task = '$description', Status = 'Not Completed' WHERE TodolistID = $id";
                    }
                    if ($conn->query($query)) {
                        header("refresh:0; url=index.php?mess=success");
                        exit;
                    } else {
                        echo "<script>console.log('Invalid query.' );</script>";
                        exit;
                    }
                }
            }
        }
        break;
    case "goalsplans":
        $query = "SELECT Status FROM goalsplans WHERE GoalsPlanID = $id";
        $result = $conn->query($query);
        if ($result) {
            if ($result->rowCount() > 0) {
                while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                    $c = $row["Status"];
                    if ($c == "Not Completed") {
                        $description = "<strike>" . $description . "</strike>";
                        $query = "UPDATE goalsplans SET ListOfGoalsPlans = '$description', Status = 'Completed' WHERE GoalsPlanID = $id";
                    } else {
                        $description = str_replace("<strike>", "", $description);
                        $description = str_replace("</strike>", "", $description);
                        $query = "UPDATE goalsplans SET ListOfGoalsPlans = '$description', Status = 'Not Completed' WHERE GoalsPlanID = $id";
                    }
                    if ($conn->query($query)) {
                        header("refresh:0; url=index.php?mess=success");
                        exit;
                    } else {
                        echo "<script>console.log('Invalid query.' );</script>";
                        exit;
                    }
                }
            }
        }
        break;
    case "appointments":
        $query = "SELECT Status FROM appointments WHERE AppointmentID = $id";
        $result = $conn->query($query);
        if ($result) {
            if ($result->rowCount() > 0) {
                while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                    $c = $row["Status"];
                    if ($c == "Not Completed") {
                        $description = "<strike>" . $description . "</strike>";
                        $query = "UPDATE appointments SET ListOfAppointments = '$description', Status = 'Completed' WHERE AppointmentID = $id";
                    } else {
                        $description = str_replace("<strike>", "", $description);
                        $description = str_replace("</strike>", "", $description);
                        $query = "UPDATE appointments SET ListOfAppointments = '$description', Status = 'Not Completed' WHERE AppointmentID = $id";
                    }
                    if ($conn->query($query)) {
                        header("refresh:0; url=index.php?mess=success");
                        exit;
                    } else {
                        echo "<script>console.log('Invalid query.' );</script>";
                        exit;
                    }
                }
            }
        }
        break;
    case "errands":
        $query = "SELECT Status FROM errands WHERE ErrandsID = $id";
        $result = $conn->query($query);
        if ($result) {
            if ($result->rowCount() > 0) {
                while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                    $c = $row["Status"];
                    if ($c == "Not Completed") {
                        $description = "<strike>" . $description . "</strike>";
                        $query = "UPDATE errands SET ListOfErrands = '$description', Status = 'Completed' WHERE ErrandsID = $id";
                    } else {
                        $description = str_replace("<strike>", "", $description);
                        $description = str_replace("</strike>", "", $description);
                        $query = "UPDATE errands SET ListOfErrands = '$description', Status = 'Not Completed' WHERE ErrandsID = $id";
                    }
                    if ($conn->query($query)) {
                        header("refresh:0; url=index.php?mess=success");
                        exit;
                    } else {
                        echo "<script>console.log('Invalid query.' );</script>";
                        exit;
                    }
                }
            }
        }
        break; 
}
