<?php
require 'db_connection.php';
$id = $_POST['id'];
$table = $_POST['table'];
$query;

switch ($table) {
    case "todolist":
        $query = "DELETE FROM todolist WHERE  TodolistID = $id";
        break;
    case "goalsplans":
        $query = "DELETE FROM goalsplans WHERE  GoalsPlanID = $id";
        break;
    case "appointments":
        $query = "DELETE FROM appointments WHERE  AppointmentID  = $id";
        break;
    case "errands":
        $query = "DELETE FROM errands WHERE  ErrandsID = $id";
        break;
}

if ($conn->query($query)) {
    header("refresh:0; url=index.php?mess=success");
    exit;
} else {
    echo "<script>console.log('Invalid query.' );</script>";
}
